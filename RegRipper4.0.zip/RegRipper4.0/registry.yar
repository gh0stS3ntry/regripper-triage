import "math"

rule Encoding
{
	meta:
	  author = "H. Carvey"
	  date = "2023-08-14"
	  reference = "https://www.elastic.co/guide/en/security/current/encoded-executable-stored-in-the-registry.html"

	strings:
	  $str1 = "TVqQAAMAAAAEAAAA"

	condition:
	  $str1
}

rule Executable
{
	meta:
	  author = "H. Carvey"
	  date = "2023-08-14"
	  reference = "https://dmfrsecurity.com/2021/12/21/100-days-of-yara-day-2-identifying-pe-files-and-measuring-speed-of-rules/"

	strings:
	  $str1 = "MZ"
	  $str2 = { 4D 5A }

	condition:
	  $str1 at 0 or $str2 at 0 or uint16(0) == 0x5a4d
}

rule Registry_Base64_Encoded_PE
{
    meta:
        description = "Base64-encoded PE (MZ header) in a registry value"
        author = "Security Analyst"
        date = "2026-10-10"
    strings:
        $mz1 = "TVqQAAMAAAAEAAAA//8AALgA" ascii wide
        $mz2 = "TVqAAAEAAAAEABAA//8AALgA" ascii wide
        $mz3 = "TVpQAAIAAAAEAA8A//8AALgA" ascii wide
    condition:
        any of them
}

rule Registry_Base64_PowerShell_UTF16LE
{
    meta:
        description = "Base64 of UTF-16LE PowerShell: stager prefix or download/execute keywords"
        author = "Security Analyst"
        date = "2026-10-10"
    strings:
        // "$s=New-Object IO.MemoryStream(,[Convert]::FromBase64String("
        $stage = "JABzAD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAEkATwAuAE0AZQBtAG8AcgB5AFMAdAByAGUAYQBtACgALABbAEMAbwBuAHYAZQByAHQAXQA6ADoARgByAG8AbQBCAGEAcwBlADYANABTAHQAcgBpAG4AZwAo" ascii wide
        // "Invoke-Expression" at the 3 base64 alignments
        $iex_0 = "SQBuAHYAbwBrAGUALQBFAHgAcAByAGUAcwBzAGkAbwBu" ascii wide
        $iex_1 = "kAbgB2AG8AawBlAC0ARQB4AHAAcgBlAHMAcwBpAG8Abg" ascii wide
        $iex_2 = "JAG4AdgBvAGsAZQAtAEUAeABwAHIAZQBzAHMAaQBvAG4A" ascii wide
        // "DownloadString"
        $dl_0 = "RABvAHcAbgBsAG8AYQBkAFMAdAByAGkAbgBn" ascii wide
        $dl_1 = "QAbwB3AG4AbABvAGEAZABTAHQAcgBpAG4AZw" ascii wide
        $dl_2 = "EAG8AdwBuAGwAbwBhAGQAUwB0AHIAaQBuAGcA" ascii wide
        // "Net.WebClient"
        $net_0 = "TgBlAHQALgBXAGUAYgBDAGwAaQBlAG4AdA" ascii wide
        $net_1 = "4AZQB0AC4AVwBlAGIAQwBsAGkAZQBuAHQA" ascii wide
        $net_2 = "OAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0" ascii wide
        // "FromBase64String"
        $fb_0 = "RgByAG8AbQBCAGEAcwBlADYANABTAHQAcgBpAG4AZw" ascii wide
        $fb_1 = "YAcgBvAG0AQgBhAHMAZQA2ADQAUwB0AHIAaQBuAGcA" ascii wide
        $fb_2 = "GAHIAbwBtAEIAYQBzAGUANgA0AFMAdAByAGkAbgBn" ascii wide
    condition:
        $stage or
        (any of ($dl_*) and any of ($net_*, $iex_*)) or
        (any of ($fb_*) and any of ($iex_*))
}

rule Registry_Base64_Generic_HighEntropy
{
    meta:
        description = "Long, high-entropy base64-like run (fallback; tune thresholds)"
        author = "Security Analyst"
        date = "2026-10-10"
    strings:
        $b64a = /[A-Za-z0-9+\/]{100,}={0,2}/ ascii
        $b64w = /[A-Za-z0-9+\/]{100,}={0,2}/ wide
    condition:
        for any i in (1..#b64a) : ( !b64a[i] >= 200 and math.entropy(@b64a[i], !b64a[i]) >= 5.4 )
        or
        for any i in (1..#b64w) : ( !b64w[i] >= 400 and math.entropy(@b64w[i], !b64w[i]) >= 3.7 )
}

/*
rule SanityCheck
{
	meta:
	  author = "MeOfCourse"
	  date = "2023-08-14"

	strings:
	  $str1 = "V3JpdGUtSG9zdCAiSGVsbG8gV29ybGQi"

	condition:
	  $str1
}
*/